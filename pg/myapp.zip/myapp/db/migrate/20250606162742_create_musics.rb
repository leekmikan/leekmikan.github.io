class CreateMusics < ActiveRecord::Migration[8.0]
  def change
    create_table :musics do |t|
      t.string :album
      t.string :title
      t.string :composer
      t.string :artist
      t.string :tracknumber
      t.integer :length
      t.integer :date

      t.timestamps
    end
  end
end
