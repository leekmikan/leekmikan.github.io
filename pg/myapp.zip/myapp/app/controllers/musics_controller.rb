require "open-uri"
class MusicsController < ApplicationController
  def index
    title = params[:title] == nil ? "" : params[:title]
    album = params[:album] == nil ? "" : params[:album]
    @musics = Music.where('title LIKE ?', "%#{title}%").where('album LIKE ?', "%#{album}%")
  end
  def show
    @music = Music.find(params[:id])
    url = "https://w.atwiki.jp/hmiku/search?andor=and&" + URI.encode_www_form(keyword: @music.title)
    uri = URI.parse(url)
    @pg = uri.read
    index = @pg.index('title="' + @music.title + '"')
    @purl = ""
    unless index == nil
        dq = 0
        while dq < 2
            if @pg[index] == '"'
                dq += 1
            elsif dq == 1
                @purl = @pg[index] + @purl
            end
            index -= 1
        end
        @purl = "https://w.atwiki.jp" + @purl
    end
  end
  def random
    if params[:time] == nil
      @get = -1
      return
    end
    @get = Integer(params[:time])
    if @get <= 0
      @get = -1
      return
    end
    @get = [@get,86400].min
    @tmp = @get * 1000
    @rt = []
    maxl = Music.maximum(:length)
    all_select = false
    while @tmp > 0
      if @tmp >= maxl and !all_select
        all_select = true
        musics = Music.where("length > ?", 0)
      elsif @tmp < maxl
        all_select = false
        musics = Music.where("length <= ?", @tmp).where("length > ?", 0)
      end
      if musics.length == 0
        break
      else
        @rt.push(musics[rand(musics.length)])
        @tmp -= @rt[@rt.length - 1].length
      end
    end
    @rt.shuffle!
  end
end
