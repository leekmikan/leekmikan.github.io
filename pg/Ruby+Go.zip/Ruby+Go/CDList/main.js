function get_data(){
    var request = new XMLHttpRequest();
    var url = "http://127.0.0.1:8080/get" +
    "?album=" + document.getElementById("album").value +  
    "&title=" + document.getElementById("title").value +  
    "&composer=" + document.getElementById("composer").value +  
    "&artist=" + document.getElementById("artist").value +  
    "&tracknumber=" + document.getElementById("tracknumber").value +  
    "&length=" + document.getElementById("length").value +  
    "&date=" + document.getElementById("date").value;
    request.open('GET', url, true);
    request.responseType = 'json';
 
    request.onload = function () {
      var data = this.response;
      var hd;
      var res = "";
      if(data === null){
        hd = "<p>検索結果：0件</p>";
        res += "<p>見つかりませんでした...</p>";
      }else{
        hd = "<p>検索結果：" + data.length + "件</p>";
        if(data.length > 100){
          res += "<p>検索結果が100件を超えてます！</p>";
        }else{
          for(var i = 0;i < data.length;i++){
            res += "<br><p>" + (i + 1) + "</p>";
            res += "<ul><li>アルバム名：" + data[i].Album 
            + "</li><li>曲名：" + data[i].Title
            + "</li><li>作曲者名：" + data[i].Composer
            + "</li><li>アーティスト名：" + data[i].Artist
            + "</li><li>トラック番号：" + data[i].Tracknumber
            + "</li><li>再生時間：" + (Number(data[i].Length) / 1000.0) + "s"
            + "</li><li>年：" + data[i].Date
            + "</li></ul>";
          }
        }
      }
      document.getElementById("result").innerHTML = hd + res;
    };
 
    request.send();
}