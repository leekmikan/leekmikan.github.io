package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strings"
)

type Music struct {
	Album       string `json:"Album"`
	Title       string `json:"Title"`
	Composer    string `json:"Composer"`
	Artist      string `json:"Artist"`
	Tracknumber string `json:"Tracknumber"`
	Length      string `json:"Length"`
	Date        string `json:"Date"`
}

// UserとIDをGETで取得(http://127.0.0.1:8080/get).
func get(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Access-Control-Allow-Origin", "*")
	switch r.Method {
	case http.MethodGet:
		w.Header().Set("Content-Type", "application/json")
		jsonFile, err := os.Open("data.json")
		if err != nil {
			fmt.Println("JSONファイルを開けません", err)
			return
		}
		defer jsonFile.Close()
		jsonData, err := io.ReadAll(jsonFile)
		if err != nil {
			fmt.Println("JSONデータを読み込めません", err)
			return
		}
		var ms []Music
		json.Unmarshal(jsonData, &ms)
		var rt []Music
		req := Music{
			Album:       r.FormValue("album"),
			Title:       r.FormValue("title"),
			Composer:    r.FormValue("composer"),
			Artist:      r.FormValue("artist"),
			Tracknumber: r.FormValue("tracknumber"),
			Length:      r.FormValue("length"),
			Date:        r.FormValue("date"),
		}
		for _, v := range ms {
			if strings.Contains(v.Album, req.Album) && strings.Contains(v.Title, req.Title) && strings.Contains(v.Composer, req.Composer) && strings.Contains(v.Artist, req.Artist) && (v.Tracknumber == req.Tracknumber || req.Tracknumber == "") && (v.Date == req.Date || req.Date == "") {
				rt = append(rt, v)
			}
		}
		post := &rt
		json, _ := json.Marshal(post)
		w.Write(json)
	default:
		fmt.Println("...")
	}
}

// (上とほぼ同じ　localhost:3000のアクセスのみ許可版)
func get_ruby(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Access-Control-Allow-Origin", "http://localhost:3000")
	switch r.Method {
	case http.MethodGet:
		w.Header().Set("Content-Type", "application/json")
		jsonFile, err := os.Open("data.json")
		if err != nil {
			fmt.Println("JSONファイルを開けません", err)
			return
		}
		defer jsonFile.Close()
		jsonData, err := io.ReadAll(jsonFile)
		if err != nil {
			fmt.Println("JSONデータを読み込めません", err)
			return
		}
		var ms []Music
		json.Unmarshal(jsonData, &ms)
		var rt []Music
		req := Music{
			Album:       r.FormValue("album"),
			Title:       r.FormValue("title"),
			Composer:    r.FormValue("composer"),
			Artist:      r.FormValue("artist"),
			Tracknumber: r.FormValue("tracknumber"),
			Length:      r.FormValue("length"),
			Date:        r.FormValue("date"),
		}
		for _, v := range ms {
			if strings.Contains(v.Album, req.Album) && strings.Contains(v.Title, req.Title) && strings.Contains(v.Composer, req.Composer) && strings.Contains(v.Artist, req.Artist) && (v.Tracknumber == req.Tracknumber || req.Tracknumber == "") && (v.Date == req.Date || req.Date == "") {
				rt = append(rt, v)
			}
		}
		post := &rt
		json, _ := json.Marshal(post)
		w.Write(json)
	default:
		fmt.Println("...")
	}
}
func main() {
	http.HandleFunc("/get", get)
	http.HandleFunc("/get_ruby", get_ruby)
	http.ListenAndServe(":8080", nil)
}
