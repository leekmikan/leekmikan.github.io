module GoHelper
end
