class Music < ApplicationRecord
end
