class GoController < ApplicationController
  def index
  end
end
